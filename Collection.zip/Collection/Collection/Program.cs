﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            College clg = new College(1000, "CDAC-PUNE");
            Boolean exit = false;
            while (exit != true)
            {
                Console.WriteLine("1-Add Student");
                Console.WriteLine("2-Remove Student Information");
                Console.WriteLine("3-Find Student's Information?");
                Console.WriteLine("4-List of Students");
                Console.WriteLine("5-Exit");
                Console.WriteLine("Select your Option:");
                int option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        Console.WriteLine("Enter your name : ");
                        string name = Console.ReadLine();
                        Console.WriteLine("Enter your city : ");
                        string city = Console.ReadLine();
                        Student sobj = new Student(name, city);
                        clg.AddStudent(sobj);
                        Console.WriteLine("Student Addedd Successfully , " + sobj.PStudentID);

                        break;
                    case 2:
                        Console.WriteLine("Enter StudentId whoes information you want to delete");
                        int id = Convert.ToInt32(Console.ReadLine());
                        bool status = clg.RemoveStudent(id);
                        if (status == true)
                        {
                            Console.WriteLine("Student Information has removed!");
                        }
                        else
                        {
                            Console.WriteLine("Student Information hasn't removed!");
                        }

                        break;
                    case 3:
                        Console.WriteLine("Enter StudentId");
                        int id1 = Convert.ToInt32(Console.ReadLine());
                        Student obj = clg.FindStudent(id1);
                        if (obj != null)
                        {
                            Console.WriteLine(obj.PStudentID + "  " + obj.PStudentName + "  " + obj.PStudentCity);
                        }
                        else
                        {
                            Console.WriteLine("Student Not Found");
                        }
                        break;
                    case 4:
                        Console.WriteLine("List of Students:");
                        clg.ShowStudents();
                        break;
                    case 5:
                        exit = true;
                        break;
                }
            }
            Console.ReadKey();
        }
    }
}

