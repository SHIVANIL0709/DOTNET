﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection
{
    class College
    {
        private int CollegeId;
        private string CollegeName;
        private List<Student> std = new List<Student>();
        public College(int CollegeId, string CollegeName)
        {
            this.CollegeId = CollegeId;
            this.CollegeName = CollegeName;
        }
        public bool AddStudent(Student sobj)
        {
            this.std.Add(sobj);
            return true;
        }
        public bool RemoveStudent(int id)
        {
            foreach(Student s in this.std)
            {
                this.std.Remove(s);
                return true;
            }
            return false;
        }
        public Student FindStudent(int id)
        {
            foreach(Student s in this.std)
            {
                if(s.PStudentID==id)
                return s;
            }
            return null;
        }
        public void ShowStudents()
        {
            foreach(Student s in this.std)
            {
                Console.WriteLine(s.ToString());
            }
        }
    }
}
