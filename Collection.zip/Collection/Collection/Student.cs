﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection
{
    class Student
    {
        private readonly int StudentId;
        private string StudentName;
        private string StudentCity;
        public static int count = 0;
        public Student(string StudentName, string StudentCity)
        {
            this.StudentId = ++Student.count;
            this.StudentName = StudentName;
            this.StudentCity = StudentCity;
        }
        public Student()
        {
            this.StudentId = ++Student.count;
        }
        public int PStudentID
        {
            get {
                return this.StudentId;
            }
        }
        public string PStudentName
        {
            get
            {
                return this.StudentName;
            }
        }
        public string PStudentCity
        {
            get
            {
                return this.StudentCity;
            }
            set
            {
                this.StudentCity=value;
            }
        }
        public override string ToString()
        {
            return this.StudentId + "  " + this.StudentName + "  " + this.StudentCity;
        }

    }
}
